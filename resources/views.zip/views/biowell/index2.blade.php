@extends('layout')
@section('formularios')
<h1>{{$titulo2}}</h1>
@endsection
