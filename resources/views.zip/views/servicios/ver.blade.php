@extends('servicios.index')
@section('productos-contenido')
<h1>{{$titulo2}}</h1>
@endsection
